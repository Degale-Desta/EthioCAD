# Academic Activities > Dataset1.1
https://universe.roboflow.com/datasetsdevelopment-ob6pc/academic-activities

Provided by a Roboflow user
License: CC BY 4.0

